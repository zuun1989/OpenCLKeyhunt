/**
 * KeyhuntCL: OpenCL-accelerated cryptocurrency puzzle solver
 * 
 * Bloom filter implementation header
 */

#ifndef BLOOM_H
#define BLOOM_H

#include <stdint.h>
#include <stddef.h>

// Bloom filter structure
typedef struct {
    uint8_t* data;
    size_t data_size;
    size_t num_hashes;
    size_t num_items;
} bloom_filter;

// Initialize a bloom filter
// capacity: expected number of items
// false_positive_rate: desired false positive rate (0 to 1)
// Returns 0 on success, non-zero on error
int bloom_init(bloom_filter* bloom, size_t capacity, double false_positive_rate);

// Add an item to the bloom filter
// Returns 0 on success, non-zero on error
int bloom_add(bloom_filter* bloom, const void* item, size_t size);

// Check if an item might be in the bloom filter
// Returns 1 if the item might be present, 0 if it's definitely not present
int bloom_check(bloom_filter* bloom, const void* item, size_t size);

// Save bloom filter to a file
// Returns 0 on success, non-zero on error
int bloom_save(bloom_filter* bloom, const char* filename);

// Load bloom filter from a file
// Returns 0 on success, non-zero on error
int bloom_load(bloom_filter* bloom, const char* filename);

// Free resources used by the bloom filter
void bloom_free(bloom_filter* bloom);

#endif /* BLOOM_H */
