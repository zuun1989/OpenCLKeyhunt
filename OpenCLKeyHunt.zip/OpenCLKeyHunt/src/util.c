/**
 * KeyhuntCL: OpenCL-accelerated cryptocurrency puzzle solver
 * 
 * Utility functions implementation
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#include "util.h"
#include "base58.h"

// Convert a hexadecimal string to bytes
int hex_to_bytes(const char* hex, uint8_t* bytes, int max_len) {
    size_t len = strlen(hex);
    
    // Check that the string has an even number of characters
    if (len % 2 != 0) {
        return -1;
    }
    
    // Make sure we don't exceed buffer size
    if (len / 2 > max_len) {
        return -1;
    }
    
    for (size_t i = 0; i < len; i += 2) {
        char byte_str[3];
        byte_str[0] = hex[i];
        byte_str[1] = hex[i + 1];
        byte_str[2] = '\0';
        
        // Check for valid hex characters
        if (!isxdigit(byte_str[0]) || !isxdigit(byte_str[1])) {
            return -1;
        }
        
        bytes[i / 2] = (uint8_t)strtol(byte_str, NULL, 16);
    }
    
    return 0;
}

// Convert a 64-bit integer to a hexadecimal string
void int64_to_hex(uint64_t value, char* hex) {
    snprintf(hex, 65, "%016llx", (unsigned long long)value);
}

// Convert a hexadecimal string to a 64-bit integer
int hex_to_int64(const char* hex, uint64_t* value) {
    char* endptr;
    
    // Check for valid hex characters
    for (const char* p = hex; *p; p++) {
        if (!isxdigit(*p)) {
            return -1;
        }
    }
    
    // Convert using strtoul
    *value = strtoull(hex, &endptr, 16);
    
    // Check if the entire string was processed
    if (*endptr != '\0') {
        return -1;
    }
    
    return 0;
}

// Decode a Bitcoin address to its byte representation
int decode_address(const char* address, uint8_t* bytes) {
    // Bitcoin addresses are base58 encoded
    size_t decoded_len = 25; // Standard length for bitcoin address data
    
    if (base58_decode(address, bytes, &decoded_len) != 0) {
        return -1;
    }
    
    if (decoded_len != 25) {
        return -1;
    }
    
    return 0;
}
