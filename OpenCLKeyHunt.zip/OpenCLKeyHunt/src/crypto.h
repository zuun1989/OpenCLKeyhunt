/**
 * KeyhuntCL: OpenCL-accelerated cryptocurrency puzzle solver
 * 
 * Cryptographic functions header
 */

#ifndef CRYPTO_H
#define CRYPTO_H

#include <stdint.h>

// Initialize cryptographic subsystem
// Returns 0 on success, non-zero on error
int crypto_init();

// Clean up cryptographic subsystem
void crypto_cleanup();

// Compute RIPEMD160 hash of public key from private key
// Returns 0 on success, non-zero on error
int crypto_compute_rmd160(uint64_t private_key, uint8_t* hash);

// Compute public key X point from private key
// Returns 0 on success, non-zero on error
int crypto_compute_xpoint(uint64_t private_key, uint8_t* xpoint);

// Compute Bitcoin address bytes from private key
// Returns 0 on success, non-zero on error
int crypto_compute_address(uint64_t private_key, uint8_t* address);

#endif /* CRYPTO_H */
