/**
 * KeyhuntCL: OpenCL-accelerated cryptocurrency puzzle solver
 * 
 * Core functionality header
 */

#ifndef KEYHUNT_H
#define KEYHUNT_H

#include <stdint.h>
#include "bloom.h"

// Hunt modes
#define MODE_NONE    0
#define MODE_RMD160  1
#define MODE_XPOINT  2
#define MODE_ADDRESS 3
#define MODE_BSGS    4

// Structure to hold search parameters
typedef struct {
    // Basic parameters
    int mode;
    char* target_file;
    char* range;
    int batch_size;
    char* bloom_file;
    char* output_file;
    int device_id;
    int platform_id;
    int num_threads;
    int use_gpu;
    int verbose;
    
    // GPU optimization parameters
    int work_group_size;     // OpenCL work group size
    int keys_per_thread;     // Number of keys processed by each thread
    int use_nvidia_optimizations; // Use NVIDIA-specific optimizations
    int use_amd_optimizations;    // Use AMD-specific optimizations
    int device_type;         // DEVICE_TYPE_* constant
    
    // Internal fields
    uint8_t* targets;
    int num_targets;
    uint64_t range_start;
    uint64_t range_end;
    uint64_t current;
    bloom_filter bloom;
    FILE* output_fd;
    
    // OpenCL context (if GPU mode)
    void* cl_context;
} hunt_params;

// Initialize default parameters
void init_params(hunt_params* params);

// Convert mode to string
const char* mode_to_str(int mode);

// Initialize keyhunt with given parameters
int init_keyhunt(hunt_params* params);

// Run the keyhunt process
void run_keyhunt(hunt_params* params, int* should_exit);

// Cleanup resources
void cleanup_keyhunt(hunt_params* params);

// CPU implementation functions
void hunt_rmd160_cpu(hunt_params* params, int* should_exit);
void hunt_xpoint_cpu(hunt_params* params, int* should_exit);
void hunt_address_cpu(hunt_params* params, int* should_exit);
void hunt_bsgs_cpu(hunt_params* params, int* should_exit);

// GPU implementation functions
void hunt_rmd160_gpu(hunt_params* params, int* should_exit);
void hunt_xpoint_gpu(hunt_params* params, int* should_exit);
void hunt_address_gpu(hunt_params* params, int* should_exit);
void hunt_bsgs_gpu(hunt_params* params, int* should_exit);

#endif /* KEYHUNT_H */
