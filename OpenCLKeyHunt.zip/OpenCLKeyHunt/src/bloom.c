/**
 * KeyhuntCL: OpenCL-accelerated cryptocurrency puzzle solver
 * 
 * Bloom filter implementation
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#include "bloom.h"

// MurmurHash2 implementation
static uint32_t murmur_hash2(const void* key, size_t len, uint32_t seed) {
    const uint32_t m = 0x5bd1e995;
    const int r = 24;
    
    uint32_t h = seed ^ len;
    
    const unsigned char* data = (const unsigned char*)key;
    
    while (len >= 4) {
        uint32_t k = *(uint32_t*)data;
        
        k *= m;
        k ^= k >> r;
        k *= m;
        
        h *= m;
        h ^= k;
        
        data += 4;
        len -= 4;
    }
    
    switch (len) {
        case 3: h ^= data[2] << 16;
        case 2: h ^= data[1] << 8;
        case 1: h ^= data[0];
                h *= m;
    };
    
    h ^= h >> 13;
    h *= m;
    h ^= h >> 15;
    
    return h;
}

// Jenkins hash function
static uint32_t jenkins_hash(const void* key, size_t len, uint32_t seed) {
    const unsigned char* data = (const unsigned char*)key;
    uint32_t hash = seed;
    
    for (size_t i = 0; i < len; ++i) {
        hash += data[i];
        hash += (hash << 10);
        hash ^= (hash >> 6);
    }
    
    hash += (hash << 3);
    hash ^= (hash >> 11);
    hash += (hash << 15);
    
    return hash;
}

// Initialize a bloom filter
int bloom_init(bloom_filter* bloom, size_t capacity, double false_positive_rate) {
    if (!bloom || capacity == 0 || false_positive_rate <= 0 || false_positive_rate >= 1) {
        return -1;
    }
    
    // Calculate optimal size and number of hash functions
    // m = -n * ln(p) / (ln(2)^2)
    // k = m/n * ln(2)
    
    double ln2 = log(2);
    double ln2_squared = ln2 * ln2;
    
    size_t m = (size_t)ceil(-1.0 * capacity * log(false_positive_rate) / ln2_squared);
    size_t k = (size_t)ceil(ln2 * m / capacity);
    
    // Ensure m is a multiple of 8 for byte alignment
    m = (m + 7) / 8 * 8;
    
    // Allocate memory for the filter
    bloom->data_size = m / 8;
    bloom->data = (uint8_t*)calloc(bloom->data_size, 1);
    if (!bloom->data) {
        return -1;
    }
    
    bloom->num_hashes = k;
    bloom->num_items = 0;
    
    return 0;
}

// Add an item to the bloom filter
int bloom_add(bloom_filter* bloom, const void* item, size_t size) {
    if (!bloom || !bloom->data || !item) {
        return -1;
    }
    
    for (size_t i = 0; i < bloom->num_hashes; i++) {
        // Use different seeds for each hash function
        uint32_t seed = i * 0xfba4c795 + 1;
        
        // Alternate between hash functions
        uint32_t hash;
        if (i % 2 == 0) {
            hash = murmur_hash2(item, size, seed);
        } else {
            hash = jenkins_hash(item, size, seed);
        }
        
        // Set the corresponding bit
        size_t bit_pos = hash % (bloom->data_size * 8);
        bloom->data[bit_pos / 8] |= (1 << (bit_pos % 8));
    }
    
    bloom->num_items++;
    
    return 0;
}

// Check if an item might be in the bloom filter
int bloom_check(bloom_filter* bloom, const void* item, size_t size) {
    if (!bloom || !bloom->data || !item) {
        return 0;
    }
    
    for (size_t i = 0; i < bloom->num_hashes; i++) {
        // Use different seeds for each hash function
        uint32_t seed = i * 0xfba4c795 + 1;
        
        // Alternate between hash functions
        uint32_t hash;
        if (i % 2 == 0) {
            hash = murmur_hash2(item, size, seed);
        } else {
            hash = jenkins_hash(item, size, seed);
        }
        
        // Check the corresponding bit
        size_t bit_pos = hash % (bloom->data_size * 8);
        if (!(bloom->data[bit_pos / 8] & (1 << (bit_pos % 8)))) {
            // If any bit is not set, the item is definitely not in the set
            return 0;
        }
    }
    
    // All bits are set, the item is probably in the set
    return 1;
}

// Save bloom filter to a file
int bloom_save(bloom_filter* bloom, const char* filename) {
    if (!bloom || !bloom->data || !filename) {
        return -1;
    }
    
    FILE* file = fopen(filename, "wb");
    if (!file) {
        return -1;
    }
    
    // Write header: data_size, num_hashes, num_items
    if (fwrite(&bloom->data_size, sizeof(size_t), 1, file) != 1 ||
        fwrite(&bloom->num_hashes, sizeof(size_t), 1, file) != 1 ||
        fwrite(&bloom->num_items, sizeof(size_t), 1, file) != 1) {
        fclose(file);
        return -1;
    }
    
    // Write data
    if (fwrite(bloom->data, 1, bloom->data_size, file) != bloom->data_size) {
        fclose(file);
        return -1;
    }
    
    fclose(file);
    return 0;
}

// Load bloom filter from a file
int bloom_load(bloom_filter* bloom, const char* filename) {
    if (!bloom || !filename) {
        return -1;
    }
    
    FILE* file = fopen(filename, "rb");
    if (!file) {
        return -1;
    }
    
    // Read header
    if (fread(&bloom->data_size, sizeof(size_t), 1, file) != 1 ||
        fread(&bloom->num_hashes, sizeof(size_t), 1, file) != 1 ||
        fread(&bloom->num_items, sizeof(size_t), 1, file) != 1) {
        fclose(file);
        return -1;
    }
    
    // Allocate memory for data
    bloom->data = (uint8_t*)malloc(bloom->data_size);
    if (!bloom->data) {
        fclose(file);
        return -1;
    }
    
    // Read data
    if (fread(bloom->data, 1, bloom->data_size, file) != bloom->data_size) {
        free(bloom->data);
        bloom->data = NULL;
        fclose(file);
        return -1;
    }
    
    fclose(file);
    return 0;
}

// Free resources used by the bloom filter
void bloom_free(bloom_filter* bloom) {
    if (bloom && bloom->data) {
        free(bloom->data);
        bloom->data = NULL;
        bloom->data_size = 0;
        bloom->num_hashes = 0;
        bloom->num_items = 0;
    }
}
