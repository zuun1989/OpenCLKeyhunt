/**
 * KeyhuntCL: OpenCL-accelerated cryptocurrency puzzle solver
 * 
 * Utility functions header
 */

#ifndef UTIL_H
#define UTIL_H

#include <stdint.h>

// Convert a hexadecimal string to bytes
// Returns 0 on success, non-zero on error
int hex_to_bytes(const char* hex, uint8_t* bytes, int max_len);

// Convert a 64-bit integer to a hexadecimal string
// The string buffer should be at least 65 bytes (64 hex chars + null)
void int64_to_hex(uint64_t value, char* hex);

// Convert a hexadecimal string to a 64-bit integer
// Returns 0 on success, non-zero on error
int hex_to_int64(const char* hex, uint64_t* value);

// Decode a Bitcoin address to its byte representation
// Returns 0 on success, non-zero on error
int decode_address(const char* address, uint8_t* bytes);

#endif /* UTIL_H */
