/**
 * KeyhuntCL: OpenCL-accelerated cryptocurrency puzzle solver
 * 
 * OpenCL context management header
 * Optimized for NVIDIA GPUs, especially GTX 1060 3GB with CUDA 12.8
 */

#ifndef OPENCL_CONTEXT_H
#define OPENCL_CONTEXT_H

#include <stdint.h>

// GPU configuration defaults optimized for NVIDIA GTX 1060 3GB
#define DEFAULT_THREAD_BLOCK_SIZE 256  // Default NVIDIA warp size (multiple of 32)
#define DEFAULT_ITEMS_PER_THREAD  16   // Number of keys each thread processes
#define DEFAULT_MAX_RESULTS     256    // Maximum results buffer size

// Device type identifiers
#define DEVICE_TYPE_ANY   0
#define DEVICE_TYPE_CPU   1
#define DEVICE_TYPE_GPU   2
#define DEVICE_TYPE_NVIDIA 3
#define DEVICE_TYPE_AMD   4

// List available OpenCL devices
void opencl_list_devices();

// Initialize OpenCL context
// Returns a pointer to the context or NULL on error
void* opencl_init(int platform_id, int device_id);

// Advanced initialization with performance optimization settings
// device_type: DEVICE_TYPE_ANY, DEVICE_TYPE_CPU, DEVICE_TYPE_GPU, etc.
// work_group_size: Preferred work group size or 0 for default
// items_per_thread: Number of keys each thread processes or 0 for default
void* opencl_init_optimized(int device_type, size_t work_group_size, int items_per_thread);

// Prepare OpenCL program for the given mode
// mode: MODE_RMD160, MODE_XPOINT, MODE_ADDRESS, or MODE_BSGS
int opencl_prepare(void* context, int mode);

// Upload targets to GPU
int opencl_upload_targets(void* context, uint8_t* targets, int num_targets, int target_size);

// Run kernel for RIPEMD160 hash search
int opencl_run_kernel_rmd160(void* context, uint64_t start_key, uint64_t batch_size, 
                             int* result_count, uint64_t** results);

// Run kernel for X point search
int opencl_run_kernel_xpoint(void* context, uint64_t start_key, uint64_t batch_size, 
                            int* result_count, uint64_t** results);

// Run kernel for address search
int opencl_run_kernel_address(void* context, uint64_t start_key, uint64_t batch_size, 
                             int* result_count, uint64_t** results);

// Run kernel for BSGS search
int opencl_run_kernel_bsgs(void* context, uint64_t start_key, uint64_t batch_size, 
                           int* result_count, uint64_t** results);

// Get device information
int opencl_get_device_info(void* context, char* name, size_t name_size, 
                          int* compute_units, uint64_t* global_mem);

// Get optimal work group size for the device
size_t opencl_get_optimal_work_group_size(void* context);

// Set performance parameters
int opencl_set_performance_parameters(void* context, size_t work_group_size, int items_per_thread);

// Cleanup OpenCL resources
void opencl_cleanup(void* context);

#endif /* OPENCL_CONTEXT_H */
