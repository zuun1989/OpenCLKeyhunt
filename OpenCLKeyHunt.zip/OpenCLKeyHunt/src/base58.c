/**
 * KeyhuntCL: OpenCL-accelerated cryptocurrency puzzle solver
 * 
 * Base58 encoding/decoding functions implementation
 */

#include <string.h>
#include <stdlib.h>

#include "base58.h"

// Base58 alphabet
static const char* base58_chars = "123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz";

// Reverse mapping for base58 decoding
static int base58_decode_map[256] = { -1 };
static int base58_decode_map_initialized = 0;

// Initialize the reverse mapping for base58 decoding
static void init_base58_decode_map() {
    if (base58_decode_map_initialized) {
        return;
    }
    
    memset(base58_decode_map, -1, sizeof(base58_decode_map));
    
    for (int i = 0; i < 58; i++) {
        base58_decode_map[(unsigned char)base58_chars[i]] = i;
    }
    
    base58_decode_map_initialized = 1;
}

// Encode binary data to Base58 string
int base58_encode(const uint8_t* data, size_t data_len, char* str, size_t* str_len) {
    if (!data || !str || !str_len || data_len == 0) {
        return -1;
    }
    
    // Count leading zeros
    size_t zeros = 0;
    while (zeros < data_len && data[zeros] == 0) {
        zeros++;
    }
    
    // Estimate output size (worst case) and check buffer
    size_t max_out_len = data_len * 138 / 100 + 1; // log(256) / log(58)
    if (*str_len < max_out_len + zeros) {
        *str_len = max_out_len + zeros;
        return -1;
    }
    
    // Allocate a temporary buffer
    uint8_t* buffer = (uint8_t*)malloc(max_out_len);
    if (!buffer) {
        return -1;
    }
    
    memset(buffer, 0, max_out_len);
    
    // Convert from base256 to base58
    size_t j, carry, high, i = 0;
    for (j = zeros; j < data_len; j++) {
        carry = data[j];
        for (high = 0; high < i || carry; high++) {
            carry += 256 * (high < i ? buffer[high] : 0);
            buffer[high] = carry % 58;
            carry /= 58;
        }
        i = high;
    }
    
    // Skip leading zeros in result
    j = 0;
    while (j < i && buffer[j] == 0) {
        j++;
    }
    
    // Add leading '1' chars for each leading zero byte
    for (size_t k = 0; k < zeros; k++) {
        str[k] = '1';
    }
    
    // Convert to base58 characters
    size_t out_pos = zeros;
    for (high = i; high > j; high--) {
        str[out_pos++] = base58_chars[buffer[high - 1]];
    }
    
    // Add null terminator
    str[out_pos] = '\0';
    *str_len = out_pos;
    
    free(buffer);
    return 0;
}

// Decode Base58 string to binary data
int base58_decode(const char* str, uint8_t* data, size_t* data_len) {
    if (!str || !data || !data_len) {
        return -1;
    }
    
    size_t str_len = strlen(str);
    if (str_len == 0) {
        *data_len = 0;
        return 0;
    }
    
    // Initialize the decode map if needed
    init_base58_decode_map();
    
    // Skip and count leading '1's
    size_t zeros = 0;
    while (zeros < str_len && str[zeros] == '1') {
        zeros++;
    }
    
    // Allocate enough space in big-endian base256 representation
    size_t output_size = (str_len - zeros) * 733 / 1000 + 1; // log(58) / log(256)
    if (*data_len < output_size + zeros) {
        *data_len = output_size + zeros;
        return -1;
    }
    
    // Allocate a temporary buffer
    uint8_t* buffer = (uint8_t*)calloc(output_size, 1);
    if (!buffer) {
        return -1;
    }
    
    // Process the characters
    for (size_t i = zeros; i < str_len; i++) {
        int v = base58_decode_map[(unsigned char)str[i]];
        if (v == -1) {
            free(buffer);
            return -1; // Invalid character
        }
        
        for (size_t j = 0; j < output_size; j++) {
            buffer[j] = buffer[j] * 58 + v;
            v = buffer[j] >> 8;
            buffer[j] &= 0xff;
        }
    }
    
    // Copy result
    memset(data, 0, zeros);
    size_t j = zeros;
    for (int i = output_size - 1; i >= 0; i--) {
        data[j++] = buffer[i];
    }
    
    *data_len = j;
    free(buffer);
    
    return 0;
}
