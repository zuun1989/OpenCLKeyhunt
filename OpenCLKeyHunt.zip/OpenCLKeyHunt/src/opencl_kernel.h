/**
 * KeyhuntCL: OpenCL-accelerated cryptocurrency puzzle solver
 * 
 * OpenCL kernel source code header
 */

#ifndef OPENCL_KERNEL_H
#define OPENCL_KERNEL_H

// OpenCL kernel for RIPEMD160 hash search
extern const char* OPENCL_KERNEL_RMD160;

// OpenCL kernel for X point search
extern const char* OPENCL_KERNEL_XPOINT;

// OpenCL kernel for address search
extern const char* OPENCL_KERNEL_ADDRESS;

// OpenCL kernel for BSGS search
extern const char* OPENCL_KERNEL_BSGS;

#endif /* OPENCL_KERNEL_H */
