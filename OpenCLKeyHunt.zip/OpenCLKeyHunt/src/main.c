/**
 * KeyhuntCL: OpenCL-accelerated cryptocurrency puzzle solver based on keyhunt
 * 
 * This is the main entry point of the application
 * Optimized for NVIDIA GTX 1060 3GB with CUDA 12.8
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <time.h>
#include <signal.h>

#include "keyhunt.h"
#include "util.h"
#include "opencl_context.h"

int should_exit = 0;

void handle_signal(int signum) {
    printf("\nReceived signal %d, exiting...\n", signum);
    should_exit = 1;
}

void print_usage() {
    printf("KeyhuntCL v1.0 - OpenCL Accelerated Cryptocurrency Puzzle Solver\n\n");
    printf("Based on keyhunt by Alberto (https://github.com/albertobsd/keyhunt)\n");
    printf("OpenCL integration inspired by BitCrack (https://github.com/brichard19/BitCrack)\n");
    printf("Optimized for NVIDIA GTX 1060 3GB with CUDA 12.8\n\n");
    
    printf("Usage:\n");
    printf("  keyhuntcl -m <mode> [options]\n\n");
    
    printf("Modes:\n");
    printf("  -m rmd160        : Search for addresses by RIPEMD160 hash\n");
    printf("  -m xpoint        : Search for public key X points\n");
    printf("  -m address       : Search for addresses\n");
    printf("  -m bsgs          : Baby Step Giant Step for public keys\n\n");
    
    printf("Options:\n");
    printf("  -f <file>        : Target file with addresses/xpoints (required)\n");
    printf("  -r <start:end>   : Range of keys to search in hex format\n");
    printf("  -i <number>      : Number of keys per iteration (default: 1048576)\n");
    printf("  -b <file>        : Read bloom filter from file\n");
    printf("  -o <file>        : Output file for found keys\n");
    printf("  -l               : List available OpenCL devices\n");
    printf("  -d <id>          : Use specific OpenCL device ID (default: 0)\n");
    printf("  -p <platform>    : Use specific OpenCL platform ID (default: 0)\n");
    printf("  -t <threads>     : Number of CPU threads when using CPU mode (default: auto)\n");
    printf("  -g               : Use GPU acceleration (OpenCL)\n");
    printf("  -c               : Use CPU mode (even if GPU is available)\n");
    printf("  -v               : Verbose mode (show more information)\n");
    printf("  -h               : Show this help\n\n");
    
    printf("NVIDIA GTX 1060 3GB Optimization Options:\n");
    printf("  --nvidia         : Use NVIDIA-optimized code (optimal for GTX 1060 3GB)\n");
    printf("  --amd            : Use AMD-optimized code\n");
    printf("  --work-size <n>  : Set custom work group size (default: 256 for NVIDIA)\n");
    printf("  --keys-per-thread <n> : Set number of keys per thread (default: 16 for NVIDIA)\n\n");
    
    printf("GPU Performance Options:\n");
    printf("  -w <size>        : Work group size (defaults: 256 for NVIDIA, 128 for others)\n");
    printf("  -k <number>      : Keys per thread (default: 16 for NVIDIA GTX 1060)\n");
    printf("  -nvidia          : Auto-optimize for NVIDIA GPUs (GTX 1060 3GB target)\n");
    printf("  -amd             : Auto-optimize for AMD GPUs\n\n");
    
    printf("Examples:\n");
    printf("  keyhuntcl -m rmd160 -f targets.txt -r 1:FFFFFFFF -gpu -nvidia\n");
    printf("  keyhuntcl -m address -f addresses.txt -gpu -i 16777216\n");
    printf("  keyhuntcl -m xpoint -f xpoints.txt -cpu -t 8\n");
    printf("  keyhuntcl -l\n\n");
    
    printf("Recommended for NVIDIA GTX 1060 3GB:\n");
    printf("  keyhuntcl -m rmd160 -f targets.txt -gpu -nvidia -i 16777216 -w 256 -k 16\n\n");
}

int main(int argc, char **argv) {
    int i;
    hunt_params params;
    int list_devices = 0;
    
    // Set up signal handlers
    signal(SIGINT, handle_signal);
    signal(SIGTERM, handle_signal);
    
    // Initialize default parameters
    init_params(&params);
    
    // Parse command line arguments
    for (i = 1; i < argc; i++) {
        if (strcmp(argv[i], "-h") == 0) {
            print_usage();
            return 0;
        } else if (strcmp(argv[i], "-m") == 0 && i + 1 < argc) {
            if (strcmp(argv[i+1], "rmd160") == 0) {
                params.mode = MODE_RMD160;
            } else if (strcmp(argv[i+1], "xpoint") == 0) {
                params.mode = MODE_XPOINT;
            } else if (strcmp(argv[i+1], "address") == 0) {
                params.mode = MODE_ADDRESS;
            } else if (strcmp(argv[i+1], "bsgs") == 0) {
                params.mode = MODE_BSGS;
            } else {
                printf("Error: Unknown mode '%s'\n", argv[i+1]);
                return 1;
            }
            i++;
        } else if (strcmp(argv[i], "-f") == 0 && i + 1 < argc) {
            params.target_file = argv[i+1];
            i++;
        } else if (strcmp(argv[i], "-r") == 0 && i + 1 < argc) {
            params.range = argv[i+1];
            i++;
        } else if (strcmp(argv[i], "-i") == 0 && i + 1 < argc) {
            params.batch_size = atoi(argv[i+1]);
            i++;
        } else if (strcmp(argv[i], "-b") == 0 && i + 1 < argc) {
            params.bloom_file = argv[i+1];
            i++;
        } else if (strcmp(argv[i], "-o") == 0 && i + 1 < argc) {
            params.output_file = argv[i+1];
            i++;
        } else if (strcmp(argv[i], "-d") == 0 && i + 1 < argc) {
            params.device_id = atoi(argv[i+1]);
            i++;
        } else if (strcmp(argv[i], "-p") == 0 && i + 1 < argc) {
            params.platform_id = atoi(argv[i+1]);
            i++;
        } else if (strcmp(argv[i], "-t") == 0 && i + 1 < argc) {
            params.num_threads = atoi(argv[i+1]);
            i++;
        } else if (strcmp(argv[i], "-w") == 0 && i + 1 < argc) {
            params.work_group_size = atoi(argv[i+1]);
            i++;
        } else if (strcmp(argv[i], "-k") == 0 && i + 1 < argc) {
            params.keys_per_thread = atoi(argv[i+1]);
            i++;
        } else if (strcmp(argv[i], "-cpu") == 0) {
            params.use_gpu = 0;
        } else if (strcmp(argv[i], "--nvidia") == 0) {
            params.use_nvidia_optimizations = 1;
            params.device_type = DEVICE_TYPE_NVIDIA;
            params.use_gpu = 1;
            
            // Set GTX 1060 default optimizations
            if (params.work_group_size == 0) {
                params.work_group_size = 256;  // Optimal for NVIDIA (multiple of 32)
            }
            if (params.keys_per_thread == 0) {
                params.keys_per_thread = 16;   // Optimal for GTX 1060
            }
            if (params.batch_size == 1048576) {
                params.batch_size = 16777216;  // Better batch size for NVIDIA
            }
            
            printf("Using NVIDIA GTX 1060 optimizations:\n");
            printf("- Work group size: %d threads\n", params.work_group_size);
            printf("- Keys per thread: %d\n", params.keys_per_thread);
            printf("- Batch size: %d keys\n", params.batch_size);
        } else if (strcmp(argv[i], "--amd") == 0) {
            params.use_amd_optimizations = 1;
            params.device_type = DEVICE_TYPE_AMD;
            params.use_gpu = 1;
            
            // Set AMD default optimizations
            if (params.work_group_size == 0) {
                params.work_group_size = 128;  // Default for AMD (smaller groups)
            }
            if (params.keys_per_thread == 0) {
                params.keys_per_thread = 8;    // Conservative for AMD
            }
        } else if (strcmp(argv[i], "--work-size") == 0 && i + 1 < argc) {
            params.work_group_size = atoi(argv[i+1]);
            i++;
        } else if (strcmp(argv[i], "--keys-per-thread") == 0 && i + 1 < argc) {
            params.keys_per_thread = atoi(argv[i+1]);
            i++;
        } else if (strcmp(argv[i], "-gpu") == 0) {
            params.use_gpu = 1;
        } else if (strcmp(argv[i], "-nvidia") == 0) {
            params.use_nvidia_optimizations = 1;
            params.device_type = DEVICE_TYPE_NVIDIA;
            
            // Set NVIDIA GTX 1060 default optimizations
            if (params.work_group_size == 0) {
                params.work_group_size = 256;  // Default for NVIDIA (multiple of 32)
            }
            if (params.keys_per_thread == 0) {
                params.keys_per_thread = 16;   // Optimal for GTX 1060
            }
            if (params.batch_size == 1048576) {
                params.batch_size = 16777216;  // Better batch size for NVIDIA
            }
        } else if (strcmp(argv[i], "-amd") == 0) {
            params.use_amd_optimizations = 1;
            params.device_type = DEVICE_TYPE_AMD;
            
            // Set AMD default optimizations
            if (params.work_group_size == 0) {
                params.work_group_size = 128;  // Default for AMD (smaller groups)
            }
            if (params.keys_per_thread == 0) {
                params.keys_per_thread = 8;    // Conservative for AMD
            }
        } else if (strcmp(argv[i], "-v") == 0) {
            params.verbose = 1;
        } else if (strcmp(argv[i], "-l") == 0) {
            list_devices = 1;
        } else {
            printf("Error: Unknown option '%s'\n", argv[i]);
            return 1;
        }
    }
    
    // List devices if requested
    if (list_devices) {
        opencl_list_devices();
        return 0;
    }
    
    // Validate parameters
    if (params.mode == MODE_NONE) {
        printf("Error: Mode (-m) not specified\n");
        print_usage();
        return 1;
    }
    
    if (params.target_file == NULL) {
        printf("Error: Target file (-f) not specified\n");
        print_usage();
        return 1;
    }
    
    if (params.range == NULL) {
        printf("Error: Range (-r) not specified\n");
        print_usage();
        return 1;
    }
    
    // Start the key hunting process
    printf("Starting KeyhuntCL with the following parameters:\n");
    printf("Mode: %s\n", mode_to_str(params.mode));
    printf("Target file: %s\n", params.target_file);
    printf("Range: %s\n", params.range);
    printf("Batch size: %d\n", params.batch_size);
    printf("Using %s processing\n", params.use_gpu ? "GPU (OpenCL)" : "CPU");
    
    if (params.use_gpu) {
        printf("OpenCL device ID: %d\n", params.device_id);
        printf("OpenCL platform ID: %d\n", params.platform_id);
    } else {
        printf("CPU threads: %d\n", params.num_threads);
    }
    
    // Initialize hunting process
    if (init_keyhunt(&params) != 0) {
        printf("Error initializing keyhunt\n");
        return 1;
    }
    
    // Run the main loop
    run_keyhunt(&params, &should_exit);
    
    // Cleanup
    cleanup_keyhunt(&params);
    
    return 0;
}
