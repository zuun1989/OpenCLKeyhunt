/**
 * KeyhuntCL: OpenCL-accelerated cryptocurrency puzzle solver
 * 
 * Base58 encoding/decoding functions header
 */

#ifndef BASE58_H
#define BASE58_H

#include <stddef.h>
#include <stdint.h>

// Encode binary data to Base58 string
// Returns 0 on success, non-zero on error
int base58_encode(const uint8_t* data, size_t data_len, char* str, size_t* str_len);

// Decode Base58 string to binary data
// Returns 0 on success, non-zero on error
int base58_decode(const char* str, uint8_t* data, size_t* data_len);

#endif /* BASE58_H */
