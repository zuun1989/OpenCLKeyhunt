/**
 * KeyhuntCL: OpenCL-accelerated cryptocurrency puzzle solver
 * 
 * Minimal secp256k1 elliptic curve implementation header
 * 
 * Note: This is a simplified version for demonstration.
 * In a real application, you would use the actual libsecp256k1 library.
 */

#ifndef SECP256K1_H
#define SECP256K1_H

#include <stdint.h>
#include <stddef.h>

// Context flags
#define SECP256K1_CONTEXT_VERIFY 1
#define SECP256K1_CONTEXT_SIGN   2

// Public key format
#define SECP256K1_EC_COMPRESSED   2
#define SECP256K1_EC_UNCOMPRESSED 4

// Forward declarations
typedef struct secp256k1_context_struct secp256k1_context;

// Opaque data structure that holds a parsed and valid public key
typedef struct {
    unsigned char data[64];
} secp256k1_pubkey;

// Create a secp256k1 context
secp256k1_context* secp256k1_context_create(unsigned int flags);

// Destroy a secp256k1 context
void secp256k1_context_destroy(secp256k1_context* ctx);

// Create a public key from a private key
int secp256k1_ec_pubkey_create(
    const secp256k1_context* ctx,
    secp256k1_pubkey* pubkey,
    const unsigned char* seckey
);

// Serialize a public key
int secp256k1_ec_pubkey_serialize(
    const secp256k1_context* ctx,
    unsigned char* output,
    size_t* outputlen,
    const secp256k1_pubkey* pubkey,
    unsigned int flags
);

#endif /* SECP256K1_H */
