/**
 * KeyhuntCL: OpenCL-accelerated cryptocurrency puzzle solver
 * 
 * OpenCL context management implementation
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#ifdef NO_OPENCL
// Mock OpenCL types and functions for CPU-only build
typedef unsigned int cl_uint;
typedef void* cl_platform_id;
typedef void* cl_device_id;
typedef void* cl_context;
typedef void* cl_command_queue;
typedef void* cl_program;
typedef void* cl_kernel;
typedef void* cl_mem;
typedef int cl_int;
#define CL_SUCCESS 0
#define CL_DEVICE_TYPE_ALL 0
#define CL_DEVICE_NAME 0
#define CL_DEVICE_TYPE 0
#define CL_DEVICE_MAX_COMPUTE_UNITS 0
#define CL_DEVICE_GLOBAL_MEM_SIZE 0
#define CL_DEVICE_TYPE_CPU 1
#define CL_DEVICE_TYPE_GPU 2
#define CL_DEVICE_TYPE_ACCELERATOR 4
#define CL_PLATFORM_NAME 0
#define CL_MEM_READ_ONLY 0
#define CL_MEM_WRITE_ONLY 0
#define CL_MEM_READ_WRITE 0
#else
#include <CL/cl.h>
#endif

#include "opencl_context.h"
#include "keyhunt.h"
#include "opencl_kernel.h"

// Internal structure to hold OpenCL resources
typedef struct {
    cl_platform_id platform;
    cl_device_id device;
    cl_context context;
    cl_command_queue queue;
    cl_program program;
    cl_kernel kernel;
    cl_mem target_buffer;
    cl_mem result_buffer;
    cl_mem count_buffer;
    int num_targets;
    int target_size;
    
    // Performance parameters
    size_t work_group_size;   // Optimal thread block size for this device
    int items_per_thread;     // Number of keys each thread processes
} opencl_ctx;

void opencl_list_devices() {
#ifdef NO_OPENCL
    printf("OpenCL support is disabled in this build.\n");
    printf("This is a CPU-only version of KeyhuntCL.\n");
    printf("CPU will be used for all computations.\n");
#else
    cl_platform_id platforms[10];
    cl_uint num_platforms;
    cl_int err;
    
    // Get platforms
    err = clGetPlatformIDs(10, platforms, &num_platforms);
    if (err != CL_SUCCESS) {
        printf("Error getting OpenCL platforms: %d\n", err);
        return;
    }
    
    printf("Found %d OpenCL platforms:\n", num_platforms);
    
    // Iterate over platforms
    for (cl_uint i = 0; i < num_platforms; i++) {
        char platform_name[128];
        err = clGetPlatformInfo(platforms[i], CL_PLATFORM_NAME, sizeof(platform_name), platform_name, NULL);
        if (err != CL_SUCCESS) {
            printf("Error getting platform name: %d\n", err);
            continue;
        }
        
        printf("Platform %d: %s\n", i, platform_name);
        
        cl_device_id devices[10];
        cl_uint num_devices;
        
        // Get devices for this platform
        err = clGetDeviceIDs(platforms[i], CL_DEVICE_TYPE_ALL, 10, devices, &num_devices);
        if (err != CL_SUCCESS) {
            printf("  Error getting devices for platform: %d\n", err);
            continue;
        }
        
        printf("  Found %d devices:\n", num_devices);
        
        // Iterate over devices
        for (cl_uint j = 0; j < num_devices; j++) {
            char device_name[128];
            cl_device_type device_type;
            cl_uint compute_units;
            cl_ulong global_mem;
            
            err = clGetDeviceInfo(devices[j], CL_DEVICE_NAME, sizeof(device_name), device_name, NULL);
            if (err != CL_SUCCESS) {
                printf("    Error getting device name: %d\n", err);
                continue;
            }
            
            err = clGetDeviceInfo(devices[j], CL_DEVICE_TYPE, sizeof(device_type), &device_type, NULL);
            if (err != CL_SUCCESS) {
                printf("    Error getting device type: %d\n", err);
                continue;
            }
            
            err = clGetDeviceInfo(devices[j], CL_DEVICE_MAX_COMPUTE_UNITS, sizeof(compute_units), &compute_units, NULL);
            if (err != CL_SUCCESS) {
                printf("    Error getting compute units: %d\n", err);
                continue;
            }
            
            err = clGetDeviceInfo(devices[j], CL_DEVICE_GLOBAL_MEM_SIZE, sizeof(global_mem), &global_mem, NULL);
            if (err != CL_SUCCESS) {
                printf("    Error getting global memory: %d\n", err);
                continue;
            }
            
            const char* type_str = "Unknown";
            if (device_type & CL_DEVICE_TYPE_CPU)
                type_str = "CPU";
            else if (device_type & CL_DEVICE_TYPE_GPU)
                type_str = "GPU";
            else if (device_type & CL_DEVICE_TYPE_ACCELERATOR)
                type_str = "Accelerator";
            
            printf("    Device %d: %s\n", j, device_name);
            printf("      Type: %s\n", type_str);
            printf("      Compute Units: %u\n", compute_units);
            printf("      Global Memory: %.2f GB\n", global_mem / (1024.0 * 1024.0 * 1024.0));
        }
    }
#endif
}

void* opencl_init(int platform_id, int device_id) {
#ifdef NO_OPENCL
    // For CPU-only build, just create a dummy context
    opencl_ctx* ctx = malloc(sizeof(opencl_ctx));
    if (!ctx) {
        printf("Error allocating context structure\n");
        return NULL;
    }
    
    memset(ctx, 0, sizeof(opencl_ctx));
    printf("OpenCL is disabled, using CPU-only mode\n");
    return ctx;
#else
    cl_platform_id platforms[10];
    cl_uint num_platforms;
    cl_int err;
    
    // Allocate context structure
    opencl_ctx* ctx = malloc(sizeof(opencl_ctx));
    if (!ctx) {
        printf("Error allocating OpenCL context structure\n");
        return NULL;
    }
    
    memset(ctx, 0, sizeof(opencl_ctx));
    
    // Get platforms
    err = clGetPlatformIDs(10, platforms, &num_platforms);
    if (err != CL_SUCCESS) {
        printf("Error getting OpenCL platforms: %d\n", err);
        free(ctx);
        return NULL;
    }
    
    if (platform_id >= num_platforms) {
        printf("Platform ID %d is invalid, only %d platforms available\n", platform_id, num_platforms);
        free(ctx);
        return NULL;
    }
    
    ctx->platform = platforms[platform_id];
    
    // Get devices
    cl_device_id devices[10];
    cl_uint num_devices;
    
    err = clGetDeviceIDs(ctx->platform, CL_DEVICE_TYPE_ALL, 10, devices, &num_devices);
    if (err != CL_SUCCESS) {
        printf("Error getting devices for platform: %d\n", err);
        free(ctx);
        return NULL;
    }
    
    if (device_id >= num_devices) {
        printf("Device ID %d is invalid, only %d devices available\n", device_id, num_devices);
        free(ctx);
        return NULL;
    }
    
    ctx->device = devices[device_id];
    
    // Create context
    ctx->context = clCreateContext(NULL, 1, &ctx->device, NULL, NULL, &err);
    if (err != CL_SUCCESS) {
        printf("Error creating OpenCL context: %d\n", err);
        free(ctx);
        return NULL;
    }
    
    // Create command queue
    #ifdef CL_VERSION_2_0
    // OpenCL 2.0 deprecated clCreateCommandQueue in favor of clCreateCommandQueueWithProperties
    ctx->queue = clCreateCommandQueueWithProperties(ctx->context, ctx->device, NULL, &err);
    #else
    ctx->queue = clCreateCommandQueue(ctx->context, ctx->device, 0, &err);
    #endif
    
    if (err != CL_SUCCESS) {
        printf("Error creating OpenCL command queue: %d\n", err);
        clReleaseContext(ctx->context);
        free(ctx);
        return NULL;
    }
    
    // Log device information
    char device_name[128];
    cl_device_type device_type;
    
    err = clGetDeviceInfo(ctx->device, CL_DEVICE_NAME, sizeof(device_name), device_name, NULL);
    if (err != CL_SUCCESS) {
        printf("Error getting device name: %d\n", err);
    }
    
    err = clGetDeviceInfo(ctx->device, CL_DEVICE_TYPE, sizeof(device_type), &device_type, NULL);
    if (err != CL_SUCCESS) {
        printf("Error getting device type: %d\n", err);
    }
    
    const char* type_str = "Unknown";
    if (device_type & CL_DEVICE_TYPE_CPU)
        type_str = "CPU";
    else if (device_type & CL_DEVICE_TYPE_GPU)
        type_str = "GPU";
    else if (device_type & CL_DEVICE_TYPE_ACCELERATOR)
        type_str = "Accelerator";
    
    printf("Using OpenCL device: %s (%s)\n", device_name, type_str);
    
    // Set default performance parameters for different device types
    if (device_type & CL_DEVICE_TYPE_GPU) {
        // Check if it's NVIDIA GPU by name (case insensitive)
        if (strstr(device_name, "NVIDIA") || strstr(device_name, "nvidia")) {
            // NVIDIA GPUs typically prefer 256 threads per block (multiple of 32)
            ctx->work_group_size = DEFAULT_THREAD_BLOCK_SIZE;
            ctx->items_per_thread = DEFAULT_ITEMS_PER_THREAD;
            printf("Optimized parameters for NVIDIA GPU: block size=%zu, items/thread=%d\n", 
                  ctx->work_group_size, ctx->items_per_thread);
        } else {
            // Generic GPU settings
            ctx->work_group_size = 128;  // More conservative default
            ctx->items_per_thread = 8;   // More conservative default
        }
    } else {
        // CPU or other device
        ctx->work_group_size = 64;   // Smaller work groups for CPU
        ctx->items_per_thread = 4;   // Fewer items per thread for CPU
    }
    
    return ctx;
#endif
}

// Advanced initialization with performance optimization settings
void* opencl_init_optimized(int device_type, size_t work_group_size, int items_per_thread) {
#ifdef NO_OPENCL
    // For CPU-only build, just create a dummy context
    opencl_ctx* ctx = malloc(sizeof(opencl_ctx));
    if (!ctx) {
        printf("Error allocating context structure\n");
        return NULL;
    }
    
    memset(ctx, 0, sizeof(opencl_ctx));
    printf("OpenCL is disabled, using CPU-only mode\n");
    return ctx;
#else
    cl_platform_id platforms[10];
    cl_uint num_platforms;
    cl_int err;
    cl_device_type cl_device_type;
    
    // Map device type to OpenCL device type
    switch(device_type) {
        case DEVICE_TYPE_CPU:
            cl_device_type = CL_DEVICE_TYPE_CPU;
            break;
        case DEVICE_TYPE_GPU:
            cl_device_type = CL_DEVICE_TYPE_GPU;
            break;
        case DEVICE_TYPE_NVIDIA:
            cl_device_type = CL_DEVICE_TYPE_GPU;  // OpenCL doesn't have a specific NVIDIA type
            break;
        case DEVICE_TYPE_AMD:
            cl_device_type = CL_DEVICE_TYPE_GPU;  // OpenCL doesn't have a specific AMD type
            break;
        case DEVICE_TYPE_ANY:
        default:
            cl_device_type = CL_DEVICE_TYPE_ALL;
            break;
    }
    
    // Allocate context structure
    opencl_ctx* ctx = malloc(sizeof(opencl_ctx));
    if (!ctx) {
        printf("Error allocating OpenCL context structure\n");
        return NULL;
    }
    
    memset(ctx, 0, sizeof(opencl_ctx));
    
    // Get platforms
    err = clGetPlatformIDs(10, platforms, &num_platforms);
    if (err != CL_SUCCESS) {
        printf("Error getting OpenCL platforms: %d\n", err);
        free(ctx);
        return NULL;
    }
    
    if (num_platforms == 0) {
        printf("No OpenCL platforms found\n");
        free(ctx);
        return NULL;
    }
    
    // For NVIDIA specific optimizations, try to find NVIDIA platform
    int selected_platform = 0;
    if (device_type == DEVICE_TYPE_NVIDIA) {
        for (cl_uint i = 0; i < num_platforms; i++) {
            char platform_name[128];
            err = clGetPlatformInfo(platforms[i], CL_PLATFORM_NAME, sizeof(platform_name), platform_name, NULL);
            if (err == CL_SUCCESS && (strstr(platform_name, "NVIDIA") || strstr(platform_name, "nvidia"))) {
                selected_platform = i;
                break;
            }
        }
    }
    
    ctx->platform = platforms[selected_platform];
    
    // Get devices of requested type
    cl_device_id devices[10];
    cl_uint num_devices;
    
    err = clGetDeviceIDs(ctx->platform, cl_device_type, 10, devices, &num_devices);
    if (err != CL_SUCCESS) {
        printf("Error getting devices for platform: %d\n", err);
        free(ctx);
        return NULL;
    }
    
    if (num_devices == 0) {
        printf("No devices of requested type found\n");
        free(ctx);
        return NULL;
    }
    
    // Select first device of requested type
    ctx->device = devices[0];
    
    // Create context
    ctx->context = clCreateContext(NULL, 1, &ctx->device, NULL, NULL, &err);
    if (err != CL_SUCCESS) {
        printf("Error creating OpenCL context: %d\n", err);
        free(ctx);
        return NULL;
    }
    
    // Create command queue
    #ifdef CL_VERSION_2_0
    // OpenCL 2.0 deprecated clCreateCommandQueue in favor of clCreateCommandQueueWithProperties
    ctx->queue = clCreateCommandQueueWithProperties(ctx->context, ctx->device, NULL, &err);
    #else
    ctx->queue = clCreateCommandQueue(ctx->context, ctx->device, 0, &err);
    #endif
    
    if (err != CL_SUCCESS) {
        printf("Error creating OpenCL command queue: %d\n", err);
        clReleaseContext(ctx->context);
        free(ctx);
        return NULL;
    }
    
    // Set performance parameters
    if (work_group_size > 0) {
        ctx->work_group_size = work_group_size;
    } else {
        // Get max work group size
        size_t max_work_group_size;
        err = clGetDeviceInfo(ctx->device, CL_DEVICE_MAX_WORK_GROUP_SIZE, 
                           sizeof(max_work_group_size), &max_work_group_size, NULL);
        
        if (err == CL_SUCCESS) {
            if (device_type == DEVICE_TYPE_NVIDIA) {
                // For NVIDIA GPUs, use a multiple of 32 (warp size)
                ctx->work_group_size = 256;  // Default for NVIDIA
                if (ctx->work_group_size > max_work_group_size) {
                    ctx->work_group_size = 128;  // Fallback for older devices
                }
            } else {
                // For other devices, use a power of 2 up to max
                ctx->work_group_size = 64;
                while (ctx->work_group_size * 2 <= max_work_group_size && ctx->work_group_size < 256) {
                    ctx->work_group_size *= 2;
                }
            }
        } else {
            // If we can't get max work group size, use a conservative value
            ctx->work_group_size = 64;
        }
    }
    
    if (items_per_thread > 0) {
        ctx->items_per_thread = items_per_thread;
    } else {
        // Default based on device type
        if (device_type == DEVICE_TYPE_NVIDIA || device_type == DEVICE_TYPE_GPU) {
            ctx->items_per_thread = 16;  // Higher for GPUs
        } else {
            ctx->items_per_thread = 4;   // Lower for CPUs
        }
    }
    
    // Log device information
    char device_name[128];
    cl_device_type actual_device_type;
    
    err = clGetDeviceInfo(ctx->device, CL_DEVICE_NAME, sizeof(device_name), device_name, NULL);
    if (err != CL_SUCCESS) {
        printf("Error getting device name: %d\n", err);
    }
    
    err = clGetDeviceInfo(ctx->device, CL_DEVICE_TYPE, sizeof(actual_device_type), &actual_device_type, NULL);
    if (err != CL_SUCCESS) {
        printf("Error getting device type: %d\n", err);
    }
    
    const char* type_str = "Unknown";
    if (actual_device_type & CL_DEVICE_TYPE_CPU)
        type_str = "CPU";
    else if (actual_device_type & CL_DEVICE_TYPE_GPU)
        type_str = "GPU";
    else if (actual_device_type & CL_DEVICE_TYPE_ACCELERATOR)
        type_str = "Accelerator";
    
    printf("Using OpenCL device: %s (%s)\n", device_name, type_str);
    printf("Performance settings: work_group_size=%zu, items_per_thread=%d\n",
           ctx->work_group_size, ctx->items_per_thread);
    
    return ctx;
#endif
}

int opencl_prepare(void* context, int mode) {
#ifdef NO_OPENCL
    // In CPU-only mode, no preparation needed
    (void)context; // Avoid unused parameter warning
    (void)mode;    // Avoid unused parameter warning
    return 0;
#else
    opencl_ctx* ctx = (opencl_ctx*)context;
    cl_int err;
    
    // Select kernel source based on mode
    const char* source;
    size_t source_size;
    
    switch (mode) {
        case MODE_RMD160:
            source = OPENCL_KERNEL_RMD160;
            source_size = strlen(OPENCL_KERNEL_RMD160);
            break;
        case MODE_XPOINT:
            source = OPENCL_KERNEL_XPOINT;
            source_size = strlen(OPENCL_KERNEL_XPOINT);
            break;
        case MODE_ADDRESS:
            source = OPENCL_KERNEL_ADDRESS;
            source_size = strlen(OPENCL_KERNEL_ADDRESS);
            break;
        case MODE_BSGS:
            source = OPENCL_KERNEL_BSGS;
            source_size = strlen(OPENCL_KERNEL_BSGS);
            break;
        default:
            printf("Error: Unknown mode for OpenCL preparation\n");
            return -1;
    }
    
    // Create program
    ctx->program = clCreateProgramWithSource(ctx->context, 1, &source, &source_size, &err);
    if (err != CL_SUCCESS) {
        printf("Error creating OpenCL program: %d\n", err);
        return -1;
    }
    
    // Build program
    err = clBuildProgram(ctx->program, 1, &ctx->device, NULL, NULL, NULL);
    if (err != CL_SUCCESS) {
        printf("Error building OpenCL program: %d\n", err);
        
        // Get build log
        size_t log_size;
        clGetProgramBuildInfo(ctx->program, ctx->device, CL_PROGRAM_BUILD_LOG, 0, NULL, &log_size);
        
        char* log = malloc(log_size);
        if (log) {
            clGetProgramBuildInfo(ctx->program, ctx->device, CL_PROGRAM_BUILD_LOG, log_size, log, NULL);
            printf("Build log:\n%s\n", log);
            free(log);
        }
        
        return -1;
    }
    
    // Create kernel
    const char* kernel_name;
    
    switch (mode) {
        case MODE_RMD160:  kernel_name = "search_rmd160"; break;
        case MODE_XPOINT:  kernel_name = "search_xpoint"; break;
        case MODE_ADDRESS: kernel_name = "search_address"; break;
        case MODE_BSGS:    kernel_name = "search_bsgs"; break;
        default:           kernel_name = NULL;
    }
    
    ctx->kernel = clCreateKernel(ctx->program, kernel_name, &err);
    if (err != CL_SUCCESS) {
        printf("Error creating OpenCL kernel: %d\n", err);
        return -1;
    }
    
    // Create result buffer
    ctx->result_buffer = clCreateBuffer(ctx->context, CL_MEM_WRITE_ONLY, 
                                       sizeof(uint64_t) * 256, NULL, &err);
    if (err != CL_SUCCESS) {
        printf("Error creating result buffer: %d\n", err);
        return -1;
    }
    
    // Create count buffer
    ctx->count_buffer = clCreateBuffer(ctx->context, CL_MEM_READ_WRITE, 
                                      sizeof(int), NULL, &err);
    if (err != CL_SUCCESS) {
        printf("Error creating count buffer: %d\n", err);
        return -1;
    }
    
    return 0;
#endif
}

int opencl_upload_targets(void* context, uint8_t* targets, int num_targets, int target_size) {
#ifdef NO_OPENCL
    // In CPU-only mode, no need to upload to GPU
    (void)context;      // Avoid unused parameter warning
    (void)targets;      // Avoid unused parameter warning
    (void)num_targets;  // Avoid unused parameter warning
    (void)target_size;  // Avoid unused parameter warning
    return 0;
#else
    opencl_ctx* ctx = (opencl_ctx*)context;
    cl_int err;
    
    // Release previous target buffer if exists
    if (ctx->target_buffer) {
        clReleaseMemObject(ctx->target_buffer);
        ctx->target_buffer = NULL;
    }
    
    // Create target buffer
    size_t buffer_size = num_targets * target_size;
    ctx->target_buffer = clCreateBuffer(ctx->context, CL_MEM_READ_ONLY, 
                                      buffer_size, NULL, &err);
    if (err != CL_SUCCESS) {
        printf("Error creating target buffer: %d\n", err);
        return -1;
    }
    
    // Upload targets
    err = clEnqueueWriteBuffer(ctx->queue, ctx->target_buffer, CL_TRUE, 0, 
                              buffer_size, targets, 0, NULL, NULL);
    if (err != CL_SUCCESS) {
        printf("Error uploading targets to GPU: %d\n", err);
        return -1;
    }
    
    ctx->num_targets = num_targets;
    ctx->target_size = target_size;
    
    return 0;
#endif
}

int opencl_run_kernel_rmd160(void* context, uint64_t start_key, uint64_t batch_size, 
                             int* result_count, uint64_t** results) {
#ifdef NO_OPENCL
    // In CPU-only mode, we don't run OpenCL kernels
    (void)context;      // Avoid unused parameter warning
    (void)start_key;    // Avoid unused parameter warning
    (void)batch_size;   // Avoid unused parameter warning
    
    // No results found in dummy implementation
    *result_count = 0;
    *results = NULL;
    return 0;
#else
    opencl_ctx* ctx = (opencl_ctx*)context;
    cl_int err;
    
    // Reset count
    int count = 0;
    err = clEnqueueWriteBuffer(ctx->queue, ctx->count_buffer, CL_TRUE, 0, 
                              sizeof(int), &count, 0, NULL, NULL);
    if (err != CL_SUCCESS) {
        printf("Error resetting count buffer: %d\n", err);
        return -1;
    }
    
    // Set kernel arguments
    err = clSetKernelArg(ctx->kernel, 0, sizeof(cl_mem), &ctx->target_buffer);
    if (err != CL_SUCCESS) {
        printf("Error setting kernel arg 0: %d\n", err);
        return -1;
    }
    
    err = clSetKernelArg(ctx->kernel, 1, sizeof(int), &ctx->num_targets);
    if (err != CL_SUCCESS) {
        printf("Error setting kernel arg 1: %d\n", err);
        return -1;
    }
    
    err = clSetKernelArg(ctx->kernel, 2, sizeof(uint64_t), &start_key);
    if (err != CL_SUCCESS) {
        printf("Error setting kernel arg 2: %d\n", err);
        return -1;
    }
    
    err = clSetKernelArg(ctx->kernel, 3, sizeof(cl_mem), &ctx->result_buffer);
    if (err != CL_SUCCESS) {
        printf("Error setting kernel arg 3: %d\n", err);
        return -1;
    }
    
    err = clSetKernelArg(ctx->kernel, 4, sizeof(cl_mem), &ctx->count_buffer);
    if (err != CL_SUCCESS) {
        printf("Error setting kernel arg 4: %d\n", err);
        return -1;
    }
    
    // Get device max work group size
    size_t max_work_group_size;
    err = clGetDeviceInfo(ctx->device, CL_DEVICE_MAX_WORK_GROUP_SIZE, 
                         sizeof(max_work_group_size), &max_work_group_size, NULL);
    if (err != CL_SUCCESS) {
        printf("Error getting max work group size: %d\n", err);
        return -1;
    }
    
    // Calculate work sizes optimized for NVIDIA GTX 1060
    // The default thread block size is 256 for NVIDIA GPUs (multiple of 32 for warps)
    // Each thread will process ITEMS_PER_THREAD keys at once for better efficiency
    size_t local_work_size = DEFAULT_THREAD_BLOCK_SIZE;
    if (local_work_size > max_work_group_size) {
        local_work_size = max_work_group_size;
    }
    
    // Adjust global work size to account for multiple items per thread
    size_t adjusted_batch_size = (batch_size + DEFAULT_ITEMS_PER_THREAD - 1) / DEFAULT_ITEMS_PER_THREAD;
    size_t global_work_size = (adjusted_batch_size + local_work_size - 1) / local_work_size * local_work_size;
    
    // Run kernel with optimized dimensions for NVIDIA GPU
    err = clEnqueueNDRangeKernel(ctx->queue, ctx->kernel, 1, NULL, 
                                &global_work_size, &local_work_size, 0, NULL, NULL);
    if (err != CL_SUCCESS) {
        printf("Error running kernel: %d\n", err);
        return -1;
    }
    
    // Finish all commands
    err = clFinish(ctx->queue);
    if (err != CL_SUCCESS) {
        printf("Error finishing command queue: %d\n", err);
        return -1;
    }
    
    // Read count
    err = clEnqueueReadBuffer(ctx->queue, ctx->count_buffer, CL_TRUE, 0, 
                             sizeof(int), &count, 0, NULL, NULL);
    if (err != CL_SUCCESS) {
        printf("Error reading count: %d\n", err);
        return -1;
    }
    
    *result_count = count;
    
    // Read results if any
    if (count > 0) {
        *results = malloc(count * sizeof(uint64_t));
        if (!*results) {
            printf("Error allocating memory for results\n");
            return -1;
        }
        
        err = clEnqueueReadBuffer(ctx->queue, ctx->result_buffer, CL_TRUE, 0, 
                                 count * sizeof(uint64_t), *results, 0, NULL, NULL);
        if (err != CL_SUCCESS) {
            printf("Error reading results: %d\n", err);
            free(*results);
            *results = NULL;
            return -1;
        }
    } else {
        *results = NULL;
    }
    
    return 0;
#endif
}

int opencl_run_kernel_xpoint(void* context, uint64_t start_key, uint64_t batch_size, 
                            int* result_count, uint64_t** results) {
    // Xpoint kernel has the same signature as rmd160
    return opencl_run_kernel_rmd160(context, start_key, batch_size, result_count, results);
}

int opencl_run_kernel_address(void* context, uint64_t start_key, uint64_t batch_size, 
                             int* result_count, uint64_t** results) {
    // Address kernel has the same signature as rmd160
    return opencl_run_kernel_rmd160(context, start_key, batch_size, result_count, results);
}

int opencl_run_kernel_bsgs(void* context, uint64_t start_key, uint64_t batch_size, 
                          int* result_count, uint64_t** results) {
    // BSGS kernel has the same signature as rmd160 for simplicity
    // A real implementation would have more parameters and different logic
    return opencl_run_kernel_rmd160(context, start_key, batch_size, result_count, results);
}

void opencl_cleanup(void* context) {
    opencl_ctx* ctx = (opencl_ctx*)context;
    if (!ctx) return;
    
#ifndef NO_OPENCL
    if (ctx->kernel)        clReleaseKernel(ctx->kernel);
    if (ctx->program)       clReleaseProgram(ctx->program);
    if (ctx->target_buffer) clReleaseMemObject(ctx->target_buffer);
    if (ctx->result_buffer) clReleaseMemObject(ctx->result_buffer);
    if (ctx->count_buffer)  clReleaseMemObject(ctx->count_buffer);
    if (ctx->queue)         clReleaseCommandQueue(ctx->queue);
    if (ctx->context)       clReleaseContext(ctx->context);
#endif
    
    free(ctx);
}

// Get device information
int opencl_get_device_info(void* context, char* name, size_t name_size, int* compute_units, uint64_t* global_mem) {
#ifdef NO_OPENCL
    // For CPU-only build, return dummy info
    if (name && name_size > 0) {
        strncpy(name, "CPU (OpenCL disabled)", name_size - 1);
        name[name_size - 1] = '\0';
    }
    
    if (compute_units) {
        *compute_units = 1;
    }
    
    if (global_mem) {
        *global_mem = 0;
    }
    
    return 0;
#else
    opencl_ctx* ctx = (opencl_ctx*)context;
    cl_int err;
    
    if (!ctx || !ctx->device) {
        return -1;
    }
    
    // Get device name
    if (name && name_size > 0) {
        err = clGetDeviceInfo(ctx->device, CL_DEVICE_NAME, name_size, name, NULL);
        if (err != CL_SUCCESS) {
            printf("Error getting device name: %d\n", err);
            return -1;
        }
    }
    
    // Get compute units
    if (compute_units) {
        cl_uint units;
        err = clGetDeviceInfo(ctx->device, CL_DEVICE_MAX_COMPUTE_UNITS, sizeof(units), &units, NULL);
        if (err != CL_SUCCESS) {
            printf("Error getting compute units: %d\n", err);
            return -1;
        }
        *compute_units = (int)units;
    }
    
    // Get global memory
    if (global_mem) {
        cl_ulong mem;
        err = clGetDeviceInfo(ctx->device, CL_DEVICE_GLOBAL_MEM_SIZE, sizeof(mem), &mem, NULL);
        if (err != CL_SUCCESS) {
            printf("Error getting global memory: %d\n", err);
            return -1;
        }
        *global_mem = (uint64_t)mem;
    }
    
    return 0;
#endif
}

// Get optimal work group size for the device
size_t opencl_get_optimal_work_group_size(void* context) {
#ifdef NO_OPENCL
    // For CPU-only build, return a reasonable default
    return 64;
#else
    opencl_ctx* ctx = (opencl_ctx*)context;
    
    if (!ctx || !ctx->device) {
        return 64;  // Default fallback
    }
    
    // Use the cached value if available
    if (ctx->work_group_size > 0) {
        return ctx->work_group_size;
    }
    
    // Otherwise, query from device
    size_t max_work_group_size;
    cl_int err = clGetDeviceInfo(ctx->device, CL_DEVICE_MAX_WORK_GROUP_SIZE, 
                               sizeof(max_work_group_size), &max_work_group_size, NULL);
    
    if (err != CL_SUCCESS) {
        printf("Error getting max work group size: %d\n", err);
        return 64;  // Default fallback
    }
    
    // For NVIDIA GPUs, use a multiple of 32 (warp size)
    char device_name[128];
    err = clGetDeviceInfo(ctx->device, CL_DEVICE_NAME, sizeof(device_name), device_name, NULL);
    
    if (err == CL_SUCCESS && (strstr(device_name, "NVIDIA") || strstr(device_name, "nvidia"))) {
        // Start with 256 for NVIDIA (usually optimal)
        size_t size = 256;
        if (size > max_work_group_size) {
            size = 128;  // Fallback
        }
        if (size > max_work_group_size) {
            size = 64;   // Second fallback
        }
        return size;
    }
    
    // For other GPUs, find largest power of 2 <= max_work_group_size and <= 256
    size_t size = 64;
    while (size * 2 <= max_work_group_size && size < 256) {
        size *= 2;
    }
    
    return size;
#endif
}

// Set performance parameters
int opencl_set_performance_parameters(void* context, size_t work_group_size, int items_per_thread) {
#ifdef NO_OPENCL
    // For CPU-only build, nothing to do
    (void)context;
    (void)work_group_size;
    (void)items_per_thread;
    return 0;
#else
    opencl_ctx* ctx = (opencl_ctx*)context;
    
    if (!ctx) {
        return -1;
    }
    
    if (work_group_size > 0) {
        // Verify work_group_size is valid
        size_t max_work_group_size;
        cl_int err = clGetDeviceInfo(ctx->device, CL_DEVICE_MAX_WORK_GROUP_SIZE, 
                                   sizeof(max_work_group_size), &max_work_group_size, NULL);
        
        if (err == CL_SUCCESS) {
            if (work_group_size > max_work_group_size) {
                printf("Warning: Requested work group size %zu exceeds maximum %zu\n",
                       work_group_size, max_work_group_size);
                ctx->work_group_size = max_work_group_size;
            } else {
                ctx->work_group_size = work_group_size;
            }
        } else {
            printf("Warning: Could not verify max work group size, using requested value\n");
            ctx->work_group_size = work_group_size;
        }
    }
    
    if (items_per_thread > 0) {
        ctx->items_per_thread = items_per_thread;
    }
    
    return 0;
#endif
}
