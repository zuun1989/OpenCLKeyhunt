/**
 * KeyhuntCL: OpenCL-accelerated cryptocurrency puzzle solver
 * 
 * Core functionality implementation
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <inttypes.h>

#include "keyhunt.h"
#include "util.h"
#include "bloom.h"
#include "opencl_context.h"
#include "crypto.h"

void init_params(hunt_params* params) {
    memset(params, 0, sizeof(hunt_params));
    
    // Basic parameters
    params->mode = MODE_NONE;
    params->batch_size = 1048576; // Default batch size
    params->num_threads = 0;      // 0 means auto-detect
    params->use_gpu = 1;          // Default to GPU mode
    params->device_id = 0;
    params->platform_id = 0;
    params->verbose = 0;
    
    // GPU optimization parameters
    params->work_group_size = 0;  // 0 means auto-detect
    params->keys_per_thread = 0;  // 0 means auto-detect
    params->use_nvidia_optimizations = 0;
    params->use_amd_optimizations = 0;
    params->device_type = DEVICE_TYPE_ANY;
}

const char* mode_to_str(int mode) {
    switch (mode) {
        case MODE_RMD160:  return "RIPEMD160";
        case MODE_XPOINT:  return "X Point";
        case MODE_ADDRESS: return "Bitcoin Address";
        case MODE_BSGS:    return "Baby Step Giant Step";
        default:           return "Unknown";
    }
}

int load_targets(hunt_params* params) {
    FILE* file;
    char line[256];
    int count = 0;
    int capacity = 1000; // Initial capacity
    uint8_t* result;
    int target_size;
    
    // Determine target size based on mode
    switch (params->mode) {
        case MODE_RMD160:
            target_size = 20; // RIPEMD160 hash is 20 bytes
            break;
        case MODE_XPOINT:
            target_size = 32; // X coordinate is 32 bytes
            break;
        case MODE_ADDRESS:
            target_size = 25; // Bitcoin address data is 25 bytes
            break;
        case MODE_BSGS:
            target_size = 33; // Compressed public key is 33 bytes
            break;
        default:
            return -1;
    }
    
    // Allocate initial memory for targets
    result = (uint8_t*)malloc(capacity * target_size);
    if (!result) {
        return -1;
    }
    
    // Open target file
    file = fopen(params->target_file, "r");
    if (!file) {
        free(result);
        return -1;
    }
    
    // Read targets from file
    while (fgets(line, sizeof(line), file)) {
        // Remove newline
        line[strcspn(line, "\r\n")] = 0;
        
        // Skip empty lines and comments
        if (line[0] == 0 || line[0] == '#') {
            continue;
        }
        
        // Expand capacity if needed
        if (count >= capacity) {
            capacity *= 2;
            result = (uint8_t*)realloc(result, capacity * target_size);
            if (!result) {
                fclose(file);
                return -1;
            }
        }
        
        // Parse target based on mode
        switch (params->mode) {
            case MODE_RMD160:
                // Parse hex RIPEMD160 hash
                if (hex_to_bytes(line, &result[count * target_size], target_size) != 0) {
                    printf("Error: Invalid RIPEMD160 hash format: %s\n", line);
                    continue;
                }
                break;
                
            case MODE_XPOINT:
                // Parse hex X point
                if (hex_to_bytes(line, &result[count * target_size], target_size) != 0) {
                    printf("Error: Invalid X point format: %s\n", line);
                    continue;
                }
                break;
                
            case MODE_ADDRESS:
                // Parse Bitcoin address
                if (decode_address(line, &result[count * target_size]) != 0) {
                    printf("Error: Invalid Bitcoin address: %s\n", line);
                    continue;
                }
                break;
                
            case MODE_BSGS:
                // Parse compressed public key
                if (hex_to_bytes(line, &result[count * target_size], target_size) != 0) {
                    printf("Error: Invalid public key format: %s\n", line);
                    continue;
                }
                break;
        }
        
        count++;
    }
    
    fclose(file);
    
    // Shrink to actual size
    result = (uint8_t*)realloc(result, count * target_size);
    
    params->targets = result;
    params->num_targets = count;
    
    printf("Loaded %d targets from %s\n", count, params->target_file);
    
    return 0;
}

int parse_range(hunt_params* params) {
    char* colon_pos;
    char start_str[65];
    char end_str[65];
    
    // Find the colon separator
    colon_pos = strchr(params->range, ':');
    if (!colon_pos) {
        printf("Error: Invalid range format (expected start:end)\n");
        return -1;
    }
    
    // Split into start and end parts
    int start_len = colon_pos - params->range;
    if (start_len > 64) {
        printf("Error: Start range too long\n");
        return -1;
    }
    
    strncpy(start_str, params->range, start_len);
    start_str[start_len] = '\0';
    
    strcpy(end_str, colon_pos + 1);
    
    // Parse hexadecimal values
    if (hex_to_int64(start_str, &params->range_start) != 0) {
        printf("Error: Invalid start range format\n");
        return -1;
    }
    
    if (hex_to_int64(end_str, &params->range_end) != 0) {
        printf("Error: Invalid end range format\n");
        return -1;
    }
    
    // Validate range
    if (params->range_start >= params->range_end) {
        printf("Error: Start range must be less than end range\n");
        return -1;
    }
    
    params->current = params->range_start;
    
    printf("Range: %" PRIx64 " to %" PRIx64 "\n", params->range_start, params->range_end);
    
    return 0;
}

int init_keyhunt(hunt_params* params) {
    // Load target addresses/xpoints
    if (load_targets(params) != 0) {
        printf("Error loading targets from %s\n", params->target_file);
        return -1;
    }
    
    // Parse key range
    if (parse_range(params) != 0) {
        return -1;
    }
    
    // Load bloom filter if specified
    if (params->bloom_file) {
        if (bloom_load(&params->bloom, params->bloom_file) != 0) {
            printf("Error loading bloom filter from %s\n", params->bloom_file);
            return -1;
        }
        printf("Loaded bloom filter from %s\n", params->bloom_file);
    } else {
        // Initialize new bloom filter
        bloom_init(&params->bloom, params->num_targets, 0.000001); // False positive rate: 0.0001%
        
        // Add targets to bloom filter
        int target_size;
        switch (params->mode) {
            case MODE_RMD160:  target_size = 20; break;
            case MODE_XPOINT:  target_size = 32; break;
            case MODE_ADDRESS: target_size = 25; break;
            case MODE_BSGS:    target_size = 33; break;
            default: return -1;
        }
        
        for (int i = 0; i < params->num_targets; i++) {
            bloom_add(&params->bloom, &params->targets[i * target_size], target_size);
        }
        
        printf("Created bloom filter with %d targets\n", params->num_targets);
    }
    
    // Open output file if specified
    if (params->output_file) {
        params->output_fd = fopen(params->output_file, "a");
        if (!params->output_fd) {
            printf("Error opening output file %s\n", params->output_file);
            return -1;
        }
    } else {
        params->output_fd = stdout;
    }
    
    // Initialize OpenCL if using GPU
    if (params->use_gpu) {
        // Use optimized initialization based on device type and parameters
        if (params->use_nvidia_optimizations || params->use_amd_optimizations) {
            int device_type = params->use_nvidia_optimizations ? DEVICE_TYPE_NVIDIA : 
                              params->use_amd_optimizations ? DEVICE_TYPE_AMD : DEVICE_TYPE_GPU;
            
            printf("Using optimized settings for %s GPUs\n", 
                   params->use_nvidia_optimizations ? "NVIDIA" : 
                   params->use_amd_optimizations ? "AMD" : "generic");
            
            params->cl_context = opencl_init_optimized(
                device_type, 
                params->work_group_size, 
                params->keys_per_thread
            );
        } else {
            params->cl_context = opencl_init(params->platform_id, params->device_id);
        }
        
        if (!params->cl_context) {
            printf("Error initializing OpenCL. Falling back to CPU mode.\n");
            params->use_gpu = 0;
        } else {
            // Display device information if available
            char device_name[128] = {0};
            int compute_units = 0;
            uint64_t global_mem = 0;
            
            if (opencl_get_device_info(params->cl_context, device_name, sizeof(device_name), 
                                      &compute_units, &global_mem) == 0) {
                printf("Using OpenCL device: %s\n", device_name);
                printf("Compute units: %d\n", compute_units);
                printf("Global memory: %.2f GB\n", global_mem / (1024.0 * 1024.0 * 1024.0));
            }
            
            // Set performance parameters if they were not already set
            if (params->work_group_size == 0 || params->keys_per_thread == 0) {
                size_t optimal_wg_size = opencl_get_optimal_work_group_size(params->cl_context);
                
                if (params->work_group_size == 0) {
                    params->work_group_size = optimal_wg_size;
                    printf("Using optimal work group size: %d\n", params->work_group_size);
                }
                
                if (params->keys_per_thread == 0) {
                    // Default key per thread values
                    if (params->use_nvidia_optimizations) {
                        params->keys_per_thread = 16;  // Optimal for NVIDIA GTX 1060
                    } else if (params->use_amd_optimizations) {
                        params->keys_per_thread = 8;   // Conservative for AMD
                    } else {
                        params->keys_per_thread = 4;   // Conservative default
                    }
                    printf("Using %d keys per thread\n", params->keys_per_thread);
                }
                
                // Apply the settings to the OpenCL context
                opencl_set_performance_parameters(params->cl_context, 
                                                params->work_group_size, 
                                                params->keys_per_thread);
            }
            
            // Prepare OpenCL program
            if (opencl_prepare(params->cl_context, params->mode) != 0) {
                printf("Error preparing OpenCL program. Falling back to CPU mode.\n");
                opencl_cleanup(params->cl_context);
                params->cl_context = NULL;
                params->use_gpu = 0;
            }
        }
    }
    
    // Initialize crypto subsystem
    if (crypto_init() != 0) {
        printf("Error initializing crypto subsystem\n");
        return -1;
    }
    
    return 0;
}

void run_keyhunt(hunt_params* params, int* should_exit) {
    // Select the appropriate function based on mode and GPU/CPU
    if (params->use_gpu) {
        switch (params->mode) {
            case MODE_RMD160:
                hunt_rmd160_gpu(params, should_exit);
                break;
            case MODE_XPOINT:
                hunt_xpoint_gpu(params, should_exit);
                break;
            case MODE_ADDRESS:
                hunt_address_gpu(params, should_exit);
                break;
            case MODE_BSGS:
                hunt_bsgs_gpu(params, should_exit);
                break;
        }
    } else {
        switch (params->mode) {
            case MODE_RMD160:
                hunt_rmd160_cpu(params, should_exit);
                break;
            case MODE_XPOINT:
                hunt_xpoint_cpu(params, should_exit);
                break;
            case MODE_ADDRESS:
                hunt_address_cpu(params, should_exit);
                break;
            case MODE_BSGS:
                hunt_bsgs_cpu(params, should_exit);
                break;
        }
    }
}

void cleanup_keyhunt(hunt_params* params) {
    // Free targets
    if (params->targets) {
        free(params->targets);
        params->targets = NULL;
    }
    
    // Clean up bloom filter
    bloom_free(&params->bloom);
    
    // Close output file if not stdout
    if (params->output_fd && params->output_fd != stdout) {
        fclose(params->output_fd);
        params->output_fd = NULL;
    }
    
    // Clean up OpenCL resources
    if (params->cl_context) {
        opencl_cleanup(params->cl_context);
        params->cl_context = NULL;
    }
    
    // Clean up crypto subsystem
    crypto_cleanup();
}

// CPU implementation functions
void hunt_rmd160_cpu(hunt_params* params, int* should_exit) {
    uint64_t keys_checked = 0;
    uint64_t total_keys = params->range_end - params->range_start;
    time_t start_time = time(NULL);
    time_t last_update = start_time;
    uint8_t hash[20];
    char private_key_hex[65];
    int target_size = 20;
    int found = 0;
    
    printf("Starting RIPEMD160 hunt using CPU...\n");
    
    while (params->current < params->range_end && !(*should_exit)) {
        uint64_t batch_size = params->batch_size;
        if (params->current + batch_size > params->range_end) {
            batch_size = params->range_end - params->current;
        }
        
        // Process a batch of keys
        for (uint64_t i = 0; i < batch_size; i++) {
            uint64_t key = params->current + i;
            
            // Compute RIPEMD160 hash of the public key derived from this private key
            if (crypto_compute_rmd160(key, hash) != 0) {
                printf("Error computing RIPEMD160 hash\n");
                continue;
            }
            
            // Check if the hash is in our bloom filter
            if (bloom_check(&params->bloom, hash, sizeof(hash))) {
                // Potential match, check against actual targets
                for (int j = 0; j < params->num_targets; j++) {
                    if (memcmp(hash, &params->targets[j * target_size], target_size) == 0) {
                        // Found a match!
                        int64_to_hex(key, private_key_hex);
                        fprintf(params->output_fd, "Found key: %s\n", private_key_hex);
                        fflush(params->output_fd);
                        found++;
                    }
                }
            }
        }
        
        // Update counters
        params->current += batch_size;
        keys_checked += batch_size;
        
        // Print status update every 5 seconds
        time_t current_time = time(NULL);
        if (current_time - last_update >= 5) {
            double elapsed = difftime(current_time, start_time);
            double speed = elapsed > 0 ? keys_checked / elapsed : 0;
            double progress = 100.0 * (params->current - params->range_start) / total_keys;
            
            printf("\rProgress: %.2f%% | Speed: %.2f keys/s | Checked: %" PRIu64 " | Found: %d", 
                   progress, speed, keys_checked, found);
            fflush(stdout);
            
            last_update = current_time;
        }
    }
    
    // Final stats
    time_t end_time = time(NULL);
    double elapsed = difftime(end_time, start_time);
    double speed = elapsed > 0 ? keys_checked / elapsed : 0;
    
    printf("\nCompleted RIPEMD160 hunt:\n");
    printf("Checked: %" PRIu64 " keys\n", keys_checked);
    printf("Found: %d matches\n", found);
    printf("Time: %.2f seconds\n", elapsed);
    printf("Speed: %.2f keys/s\n", speed);
}

void hunt_xpoint_cpu(hunt_params* params, int* should_exit) {
    uint64_t keys_checked = 0;
    uint64_t total_keys = params->range_end - params->range_start;
    time_t start_time = time(NULL);
    time_t last_update = start_time;
    uint8_t xpoint[32];
    char private_key_hex[65];
    int target_size = 32;
    int found = 0;
    
    printf("Starting X Point hunt using CPU...\n");
    
    while (params->current < params->range_end && !(*should_exit)) {
        uint64_t batch_size = params->batch_size;
        if (params->current + batch_size > params->range_end) {
            batch_size = params->range_end - params->current;
        }
        
        // Process a batch of keys
        for (uint64_t i = 0; i < batch_size; i++) {
            uint64_t key = params->current + i;
            
            // Compute public key X point from private key
            if (crypto_compute_xpoint(key, xpoint) != 0) {
                printf("Error computing X point\n");
                continue;
            }
            
            // Check if the X point is in our bloom filter
            if (bloom_check(&params->bloom, xpoint, sizeof(xpoint))) {
                // Potential match, check against actual targets
                for (int j = 0; j < params->num_targets; j++) {
                    if (memcmp(xpoint, &params->targets[j * target_size], target_size) == 0) {
                        // Found a match!
                        int64_to_hex(key, private_key_hex);
                        fprintf(params->output_fd, "Found key for X point: %s\n", private_key_hex);
                        fflush(params->output_fd);
                        found++;
                    }
                }
            }
        }
        
        // Update counters
        params->current += batch_size;
        keys_checked += batch_size;
        
        // Print status update every 5 seconds
        time_t current_time = time(NULL);
        if (current_time - last_update >= 5) {
            double elapsed = difftime(current_time, start_time);
            double speed = elapsed > 0 ? keys_checked / elapsed : 0;
            double progress = 100.0 * (params->current - params->range_start) / total_keys;
            
            printf("\rProgress: %.2f%% | Speed: %.2f keys/s | Checked: %" PRIu64 " | Found: %d", 
                   progress, speed, keys_checked, found);
            fflush(stdout);
            
            last_update = current_time;
        }
    }
    
    // Final stats
    time_t end_time = time(NULL);
    double elapsed = difftime(end_time, start_time);
    double speed = elapsed > 0 ? keys_checked / elapsed : 0;
    
    printf("\nCompleted X Point hunt:\n");
    printf("Checked: %" PRIu64 " keys\n", keys_checked);
    printf("Found: %d matches\n", found);
    printf("Time: %.2f seconds\n", elapsed);
    printf("Speed: %.2f keys/s\n", speed);
}

void hunt_address_cpu(hunt_params* params, int* should_exit) {
    uint64_t keys_checked = 0;
    uint64_t total_keys = params->range_end - params->range_start;
    time_t start_time = time(NULL);
    time_t last_update = start_time;
    uint8_t address[25];
    char private_key_hex[65];
    int target_size = 25;
    int found = 0;
    
    printf("Starting Address hunt using CPU...\n");
    
    while (params->current < params->range_end && !(*should_exit)) {
        uint64_t batch_size = params->batch_size;
        if (params->current + batch_size > params->range_end) {
            batch_size = params->range_end - params->current;
        }
        
        // Process a batch of keys
        for (uint64_t i = 0; i < batch_size; i++) {
            uint64_t key = params->current + i;
            
            // Compute address data from private key
            if (crypto_compute_address(key, address) != 0) {
                printf("Error computing address\n");
                continue;
            }
            
            // Check if the address is in our bloom filter
            if (bloom_check(&params->bloom, address, sizeof(address))) {
                // Potential match, check against actual targets
                for (int j = 0; j < params->num_targets; j++) {
                    if (memcmp(address, &params->targets[j * target_size], target_size) == 0) {
                        // Found a match!
                        int64_to_hex(key, private_key_hex);
                        fprintf(params->output_fd, "Found key for address: %s\n", private_key_hex);
                        fflush(params->output_fd);
                        found++;
                    }
                }
            }
        }
        
        // Update counters
        params->current += batch_size;
        keys_checked += batch_size;
        
        // Print status update every 5 seconds
        time_t current_time = time(NULL);
        if (current_time - last_update >= 5) {
            double elapsed = difftime(current_time, start_time);
            double speed = elapsed > 0 ? keys_checked / elapsed : 0;
            double progress = 100.0 * (params->current - params->range_start) / total_keys;
            
            printf("\rProgress: %.2f%% | Speed: %.2f keys/s | Checked: %" PRIu64 " | Found: %d", 
                   progress, speed, keys_checked, found);
            fflush(stdout);
            
            last_update = current_time;
        }
    }
    
    // Final stats
    time_t end_time = time(NULL);
    double elapsed = difftime(end_time, start_time);
    double speed = elapsed > 0 ? keys_checked / elapsed : 0;
    
    printf("\nCompleted Address hunt:\n");
    printf("Checked: %" PRIu64 " keys\n", keys_checked);
    printf("Found: %d matches\n", found);
    printf("Time: %.2f seconds\n", elapsed);
    printf("Speed: %.2f keys/s\n", speed);
}

void hunt_bsgs_cpu(hunt_params* params, int* should_exit) {
    printf("Baby Step Giant Step method using CPU...\n");
    printf("Note: BSGS implementation is more complex and requires larger memory\n");
    
    // For brevity, we're not implementing the full BSGS algorithm here
    // The actual implementation would use the method described in the original keyhunt
    
    printf("BSGS not fully implemented in CPU mode yet\n");
}

// GPU implementation functions using OpenCL
void hunt_rmd160_gpu(hunt_params* params, int* should_exit) {
    uint64_t keys_checked = 0;
    uint64_t total_keys = params->range_end - params->range_start;
    time_t start_time = time(NULL);
    time_t last_update = start_time;
    int found = 0;
    int result_count = 0;
    uint64_t* results = NULL;
    
    // Calculate effective batch size based on GPU optimization parameters
    uint64_t effective_batch_size = params->batch_size;
    if (params->keys_per_thread > 0) {
        // Each thread processes multiple keys, so we need to adjust the actual work size
        effective_batch_size = params->batch_size / params->keys_per_thread;
        
        if (effective_batch_size == 0) {
            effective_batch_size = 1;  // Ensure at least one work unit
        }
        
        // Align to work group size if specified
        if (params->work_group_size > 0) {
            uint64_t remainder = effective_batch_size % params->work_group_size;
            if (remainder != 0) {
                effective_batch_size += params->work_group_size - remainder;
            }
        }
        
        // The real number of keys processed will be effective_batch_size * keys_per_thread
        printf("GPU optimization: processing %d keys per thread\n", params->keys_per_thread);
        printf("Work group size: %d threads\n", params->work_group_size);
    }
    
    // Print startup information
    printf("Starting RIPEMD160 hunt using GPU (OpenCL)...\n");
    printf("Range: %016" PRIx64 " - %016" PRIx64 " (%" PRIu64 " keys)\n", 
           params->range_start, params->range_end, total_keys);
    printf("Batch size: %u keys per iteration\n", params->batch_size);
    
    if (params->use_nvidia_optimizations) {
        printf("Using NVIDIA-optimized code for GTX 1060\n");
    } else if (params->use_amd_optimizations) {
        printf("Using AMD-optimized code\n");
    }
    
    // Upload targets to GPU
    if (opencl_upload_targets(params->cl_context, params->targets, params->num_targets, 20) != 0) {
        printf("Error uploading targets to GPU\n");
        return;
    }
    
    while (params->current < params->range_end && !(*should_exit)) {
        uint64_t batch_size = params->batch_size;
        if (params->current + batch_size > params->range_end) {
            batch_size = params->range_end - params->current;
        }
        
        // Run the kernel to process a batch
        if (opencl_run_kernel_rmd160(params->cl_context, params->current, batch_size, &result_count, &results) != 0) {
            printf("Error running OpenCL kernel\n");
            break;
        }
        
        // Process any found keys
        for (int i = 0; i < result_count; i++) {
            uint64_t key = results[i];
            char private_key_hex[65];
            int64_to_hex(key, private_key_hex);
            fprintf(params->output_fd, "Found key: %s\n", private_key_hex);
            fflush(params->output_fd);
            found++;
        }
        
        // Free result buffer if allocated
        if (results) {
            free(results);
            results = NULL;
        }
        
        // Update counters
        params->current += batch_size;
        keys_checked += batch_size;
        
        // Print status update every 5 seconds
        time_t current_time = time(NULL);
        if (current_time - last_update >= 5) {
            double elapsed = difftime(current_time, start_time);
            double speed = elapsed > 0 ? keys_checked / elapsed : 0;
            double progress = 100.0 * (params->current - params->range_start) / total_keys;
            
            printf("\rProgress: %.2f%% | Speed: %.2f keys/s | Checked: %" PRIu64 " | Found: %d", 
                   progress, speed, keys_checked, found);
            fflush(stdout);
            
            last_update = current_time;
        }
    }
    
    // Final stats
    time_t end_time = time(NULL);
    double elapsed = difftime(end_time, start_time);
    double speed = elapsed > 0 ? keys_checked / elapsed : 0;
    
    printf("\nCompleted RIPEMD160 hunt (GPU):\n");
    printf("Checked: %" PRIu64 " keys\n", keys_checked);
    printf("Found: %d matches\n", found);
    printf("Time: %.2f seconds\n", elapsed);
    printf("Speed: %.2f keys/s\n", speed);
}

void hunt_xpoint_gpu(hunt_params* params, int* should_exit) {
    uint64_t keys_checked = 0;
    uint64_t total_keys = params->range_end - params->range_start;
    time_t start_time = time(NULL);
    time_t last_update = start_time;
    int found = 0;
    int result_count = 0;
    uint64_t* results = NULL;
    
    printf("Starting X Point hunt using GPU (OpenCL)...\n");
    
    // Upload targets to GPU
    if (opencl_upload_targets(params->cl_context, params->targets, params->num_targets, 32) != 0) {
        printf("Error uploading targets to GPU\n");
        return;
    }
    
    while (params->current < params->range_end && !(*should_exit)) {
        uint64_t batch_size = params->batch_size;
        if (params->current + batch_size > params->range_end) {
            batch_size = params->range_end - params->current;
        }
        
        // Run the kernel to process a batch
        if (opencl_run_kernel_xpoint(params->cl_context, params->current, batch_size, &result_count, &results) != 0) {
            printf("Error running OpenCL kernel\n");
            break;
        }
        
        // Process any found keys
        for (int i = 0; i < result_count; i++) {
            uint64_t key = results[i];
            char private_key_hex[65];
            int64_to_hex(key, private_key_hex);
            fprintf(params->output_fd, "Found key for X point: %s\n", private_key_hex);
            fflush(params->output_fd);
            found++;
        }
        
        // Free result buffer if allocated
        if (results) {
            free(results);
            results = NULL;
        }
        
        // Update counters
        params->current += batch_size;
        keys_checked += batch_size;
        
        // Print status update every 5 seconds
        time_t current_time = time(NULL);
        if (current_time - last_update >= 5) {
            double elapsed = difftime(current_time, start_time);
            double speed = elapsed > 0 ? keys_checked / elapsed : 0;
            double progress = 100.0 * (params->current - params->range_start) / total_keys;
            
            printf("\rProgress: %.2f%% | Speed: %.2f keys/s | Checked: %" PRIu64 " | Found: %d", 
                   progress, speed, keys_checked, found);
            fflush(stdout);
            
            last_update = current_time;
        }
    }
    
    // Final stats
    time_t end_time = time(NULL);
    double elapsed = difftime(end_time, start_time);
    double speed = elapsed > 0 ? keys_checked / elapsed : 0;
    
    printf("\nCompleted X Point hunt (GPU):\n");
    printf("Checked: %" PRIu64 " keys\n", keys_checked);
    printf("Found: %d matches\n", found);
    printf("Time: %.2f seconds\n", elapsed);
    printf("Speed: %.2f keys/s\n", speed);
}

void hunt_address_gpu(hunt_params* params, int* should_exit) {
    uint64_t keys_checked = 0;
    uint64_t total_keys = params->range_end - params->range_start;
    time_t start_time = time(NULL);
    time_t last_update = start_time;
    int found = 0;
    int result_count = 0;
    uint64_t* results = NULL;
    
    printf("Starting Address hunt using GPU (OpenCL)...\n");
    
    // Upload targets to GPU
    if (opencl_upload_targets(params->cl_context, params->targets, params->num_targets, 25) != 0) {
        printf("Error uploading targets to GPU\n");
        return;
    }
    
    while (params->current < params->range_end && !(*should_exit)) {
        uint64_t batch_size = params->batch_size;
        if (params->current + batch_size > params->range_end) {
            batch_size = params->range_end - params->current;
        }
        
        // Run the kernel to process a batch
        if (opencl_run_kernel_address(params->cl_context, params->current, batch_size, &result_count, &results) != 0) {
            printf("Error running OpenCL kernel\n");
            break;
        }
        
        // Process any found keys
        for (int i = 0; i < result_count; i++) {
            uint64_t key = results[i];
            char private_key_hex[65];
            int64_to_hex(key, private_key_hex);
            fprintf(params->output_fd, "Found key for address: %s\n", private_key_hex);
            fflush(params->output_fd);
            found++;
        }
        
        // Free result buffer if allocated
        if (results) {
            free(results);
            results = NULL;
        }
        
        // Update counters
        params->current += batch_size;
        keys_checked += batch_size;
        
        // Print status update every 5 seconds
        time_t current_time = time(NULL);
        if (current_time - last_update >= 5) {
            double elapsed = difftime(current_time, start_time);
            double speed = elapsed > 0 ? keys_checked / elapsed : 0;
            double progress = 100.0 * (params->current - params->range_start) / total_keys;
            
            printf("\rProgress: %.2f%% | Speed: %.2f keys/s | Checked: %" PRIu64 " | Found: %d", 
                   progress, speed, keys_checked, found);
            fflush(stdout);
            
            last_update = current_time;
        }
    }
    
    // Final stats
    time_t end_time = time(NULL);
    double elapsed = difftime(end_time, start_time);
    double speed = elapsed > 0 ? keys_checked / elapsed : 0;
    
    printf("\nCompleted Address hunt (GPU):\n");
    printf("Checked: %" PRIu64 " keys\n", keys_checked);
    printf("Found: %d matches\n", found);
    printf("Time: %.2f seconds\n", elapsed);
    printf("Speed: %.2f keys/s\n", speed);
}

void hunt_bsgs_gpu(hunt_params* params, int* should_exit) {
    printf("Baby Step Giant Step method using GPU (OpenCL)...\n");
    printf("Note: BSGS implementation is more complex and requires larger memory\n");
    
    // For brevity, we're not implementing the full BSGS algorithm here
    // The actual implementation would use the method described in the original keyhunt but with OpenCL
    
    printf("BSGS not fully implemented in GPU mode yet\n");
}
